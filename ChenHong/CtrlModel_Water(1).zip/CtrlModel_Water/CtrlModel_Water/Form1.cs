﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CS_Object;
using System.Speech.Synthesis;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace CtrlModel_Water
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            wt_use.tag_name = "WT_USE";
            wt_fact.tag_name = "WT_FACT";
            dh_002.tag_name = "DH_002";

            fitls.tag_name = "FItls";
            fishccs.tag_name = "FIshccs";
            fi1115.tag_name = "FI1115";
            fi1116.tag_name = "FI1116";
            fi1117.tag_name = "FI1117";
            fi1118.tag_name = "FI1118";
            fi201.tag_name = "FI201";
            fi202.tag_name = "FI202";
            wi117.tag_name = "WI117";
            wi118.tag_name = "WI118";
            FI_201_SET.tag_name= "FI_201_SET_L2";
            
            progressBar1.Visible = true;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Value = 0;
            progressBar1.Step = 1;

            progressBar2.Visible = true;
            progressBar2.Minimum = 0;
            progressBar2.Maximum = 100;
            progressBar2.Value = 0;
            progressBar2.Step = 1;

            progressBar3.Visible = true;
            progressBar3.Minimum = 0;
            progressBar3.Maximum = 100;
            progressBar3.Value = 0;
            progressBar3.Step = 1;

            progressBar4.Visible = true;
            progressBar4.Minimum = 0;
            progressBar4.Maximum = 100;
            progressBar4.Value = 0;
            progressBar4.Step = 1;


            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                CS_Object.initServerObject.initRemotServer("10.160.8.202", "TagChannel", "8088");

            }
            catch { };
        }

        // 数据库连接字符串
        string connectionString = "Data Source=10.160.8.201;Initial Catalog=CIEexpert_DB1;User ID=sa;Password=cieexpert666";


        public class Name_IP
        {//用于记录变量名+变量地址
            public string tag_name = "Non";
            public int Ip = 0;
        };

        Name_IP wt_use = new Name_IP();
        Name_IP wt_fact = new Name_IP();
        Name_IP fitls = new Name_IP();
        Name_IP fishccs = new Name_IP();
        Name_IP fi1115 = new Name_IP();
        Name_IP fi1116 = new Name_IP();
        Name_IP fi1117 = new Name_IP();
        Name_IP fi1118 = new Name_IP();
        Name_IP fi201 = new Name_IP();
        Name_IP fi202 = new Name_IP();
        Name_IP wi117 = new Name_IP();
        Name_IP wi118 = new Name_IP();

        Name_IP FI_201_SET = new Name_IP();

        Name_IP dh_002= new Name_IP();



        float YH_MI_set = 4.2f;
        double ERH_MI_set = 4.2;
        double MI_initial = 4.5;
        float Wt_use = 0;
        float Wt_fact = 0;
        float Fitls = 0;
        float Fishccs = 0;

        float Fi1115 = 0;
        float Fi1116 = 0;
        float Fi1117 = 0;
        float Fi1118 = 0;
        float FI201 = 0;
        float FI202 = 0;
        float Wi117 = 0;
        float Wi118 = 0;
        //原始数组
        float[] Data_Fi1115 = new float[22];
        float[] Data_Fi1116 = new float[22];
        float[] Data_Fi1117 = new float[22];
        float[] Data_Fi1118 = new float[22];
        float[] Data_Fitls = new float[22];
        float[] Data_Fishccs = new float[22];
        float[] Data_Fi201 = new float[22];
        float[] Data_Fi202 = new float[22];
        float[] Data_Wi117 = new float[22];
        float[] Data_Wi118 = new float[22];
        float[] Data_Wt_fact = new float[22];

        //平滑数组
        float[] Smoothness_Data_Fi1115 = new float[22];
        float[] Smoothness_Data_Fi1116 = new float[22];
        float[] Smoothness_Data_Fi1117 = new float[22];
        float[] Smoothness_Data_Fi1118 = new float[22];
        float[] Smoothness_Data_Fitls = new float[22];
        float[] Smoothness_Data_Fishccs = new float[22];
        float[] Smoothness_Data_Wi117 = new float[22];
        float[] Smoothness_Data_Wi118 = new float[22];
        float[] Smoothness_Data_Fi201 = new float[22];
        float[] Smoothness_Data_Fi202 = new float[22];


        String time;
        double gd_mse_Fi1117 = 2;
        double gd_mse_Fi1118 = 2;
        double gd_mse_TL = 9;
        double gd_mse_CC = 9;
        bool isPlaying = false ;
        int databox = 5;
        double FI201_up = 3.0;
        double FI201_down = 1.0;

        private bool ReadTagDI(Name_IP Tag, ref bool Value)
        {//读TAG DI
            bool sta = false;
            bool Fx = false;

            try
            {
                if (!CS_Object.initServerObject.Tagserverobject.APIWGetDV(Tag.tag_name, ref Value, ref sta, ref Tag.Ip))
                {
                    Tag.Ip = 0;

                }
                else
                {
                    if (sta) Fx = true;
                }
            }
            catch
            {
                Tag.Ip = 0;

            };

            return Fx;
        }
        private bool ReadTagAI(Name_IP Tag, ref float Value)
        {
            bool sta = false;
            int reas = 0;
            bool Fx = false;

            try
            {
                if (!CS_Object.initServerObject.Tagserverobject.APIWGetValue(Tag.tag_name, ref Value, ref sta, ref Tag.Ip, ref reas))//本地读
                {
                    Tag.Ip = 0;
                    //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "读不成功！", EventLogEntryType.Error);
                }
                else
                {
                    if (sta) Fx = true;
                }
            }
            catch
            {
                Tag.Ip = 0;
                //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "访问不成功！", EventLogEntryType.Error);
            };

            return Fx;
        }
        private bool WriteTagAI(Name_IP Tag, float Value)
        {//读TAG DI

            bool Fx = false;

            try
            {
                if (!CS_Object.initServerObject.Tagserverobject.APIWSetValue_TOOPC(Tag.tag_name, Value, ref Tag.Ip))//本地写
                {
                    Tag.Ip = 0;
                    //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "写不成功！", EventLogEntryType.Error);
                }
                else
                {
                    Fx = true;
                }
            }
            catch
            {
                Tag.Ip = 0;
                //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "访问不成功！", EventLogEntryType.Error);
            };

            return Fx;
        }
        private void UpdateData(float[] Data, float num)
        {
            int n = (int)Data[21];
            Data[n] = num;
            n = (n + 1) % 20;
            Data[21] = (float)n;
        }

        private float Smoothness(float[] Data, float num, int databox)
        {
            int n = (int)Data[21];
            float mean = num;
            float result = 0;
            if (Data[20] == 0 && n < databox)
            {
                for (int i = 0; i < n; i++)
                    mean += Data[i];
                result = mean / (n + 1);
            }
            else
            {
                for (int i = 0; i < databox-1; i++)
                    mean += Data[(n - i + 19) % 20];
                result = mean / databox;
            }
            return result;
        }
        private float MSE(float[] Data, float num)
        {
            int n = (int)Data[21];
            Data[n] = num;
            float mean = 0;
            float mse = 0;
            for (int i = 0; i < 20; i++)
                mean += Data[i];
            if (Data[20] == 0)
            {
                mean /= (n + 1);
                for (int i = 0; i <= n; i++)
                    mse += (Data[i] - mean) * (Data[i] - mean);
                mse /= (n + 1);
                n++;
                if (n == 19)
                    Data[20] = 1;
            }
            else
            {
                mean /= 20;
                for (int i = 0; i < 20; i++)
                    mse += (Data[i] - mean) * (Data[i] - mean);
                mse /= 20;
                n = (n + 1) % 20;
            }
            Data[21] = (float)n;
            return mse;
        }

        private void Remind(float mse, ProgressBar pbar ,string tag_name, double gd_mse)
        {

            //-----------生石灰槽加水流量异常播报----------------------------------------------------------------
            if (mse >= gd_mse)
            {
                pbar.Value = 100;

                // 弹窗提示
                time = System.DateTime.Now.ToString();
                dataGridView1.Rows.Add(tag_name, time, mse);
                if (!isPlaying)
                    isPlaying = true;
                // 将发生异常的时间点及值保存到数据库
            }
            else
            {
                pbar.Value = (int)(mse / gd_mse * 100);
            }
        }
        private async Task PlayVedio(string message)
        {
            await Task.Delay(5000);
            using (SpeechSynthesizer synthesizer = new SpeechSynthesizer())
            {
                synthesizer.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Adult);
                synthesizer.Volume = 100;
                synthesizer.Rate = 0; // 范围从-10到10
                //String tempmse = mse.ToString("F2");

                

                await Task.Delay(3000);
                // 播放文本
                if(!synthesizer.Equals(message))
                    synthesizer.Speak(message);
                isPlaying = false;
                
            }
        }




        private async void timer1_Tick(object sender, EventArgs e)
        {
            // 读数据
            ReadTagAI(wt_use, ref Wt_use);
            ReadTagAI(wt_fact, ref Wt_fact);
            ReadTagAI(fitls, ref Fitls);
            ReadTagAI(fishccs, ref Fishccs);
            ReadTagAI(fi1115, ref Fi1115);
            ReadTagAI(fi1116, ref Fi1116);
            ReadTagAI(fi1117, ref Fi1117);
            ReadTagAI(fi1118, ref Fi1118);
            ReadTagAI(fi201, ref FI201);
            ReadTagAI(fi202, ref FI202);
            ReadTagAI(wi117, ref Wi117);
            ReadTagAI(wi118, ref Wi118);


            //平滑处理 + 更新数据
            UpdateData(Smoothness_Data_Fi1117, Smoothness(Data_Fi1117, Fi1117, databox ));

            //WriteTagAI();
            UpdateData(Data_Wt_fact, Wt_fact);
            UpdateData(Smoothness_Data_Fi1118, Smoothness(Data_Fi1118, Fi1118, databox));
            UpdateData(Smoothness_Data_Fishccs, Smoothness(Data_Fitls, Fitls, databox));
            UpdateData(Smoothness_Data_Fitls, Smoothness(Data_Fishccs, Fishccs, databox));
            UpdateData(Smoothness_Data_Fi1115, Smoothness(Smoothness_Data_Fi1115, Fi1115, databox));
            UpdateData(Smoothness_Data_Fi1116, Smoothness(Smoothness_Data_Fi1116, Fi1116, databox));
            UpdateData(Smoothness_Data_Fi201, Smoothness(Smoothness_Data_Fi201, FI201, databox));
            UpdateData(Smoothness_Data_Fi202, Smoothness(Smoothness_Data_Fi202, FI202, databox));

            UpdateData(Smoothness_Data_Wi117, Smoothness(Smoothness_Data_Wi117, Wi117, databox));
            UpdateData(Smoothness_Data_Wi118, Smoothness(Smoothness_Data_Wi118, Wi118, databox));
            /*UpdateData(Data_Wi117, Wi117);
            float sm_num = Smoothness(Data_Wi117, Wi117);
            UpdateData(Smoothness_Data_Wi117, sm_num );

            UpdateData(Data_Wi118, Wi118);
            sm_num = Smoothness(Data_Wi118, Wi118);
            UpdateData(Smoothness_Data_Wi117, sm_num );*/

            int n = ((int)Smoothness_Data_Wi117[21] + 19) % 20;


            //计算加水和
            //float sum = (Fitls + Fishccs + Fi1117 + Fi1118 + FI201 + FI202 + Fi1115 + Fi1116);
            //float XH_sum = (Fi1115 + Fi1116+Fi1117 + Fi1118 + Fitls + Fishccs  );
            //float YH_sum = (Fi1115 + Fi1116 + Fi1117 + Fi1118 + Fitls + Fishccs + FI201);

            float sum = (Smoothness_Data_Fitls[n] + Smoothness_Data_Fishccs[n] + Smoothness_Data_Fi1117[n] + Smoothness_Data_Fi1118[n] + Smoothness_Data_Fi201[n] + Smoothness_Data_Fi202[n] + Smoothness_Data_Fi1115[n] + Smoothness_Data_Fi1116[n]);
            float XH_sum = (Smoothness_Data_Fi1115[n] + Smoothness_Data_Fi1116[n] + Smoothness_Data_Fi1117[n] + Smoothness_Data_Fi1118[n] + Smoothness_Data_Fitls[n] + Smoothness_Data_Fishccs[n]);
            if((int)Smoothness_Data_Wi117[20] == 1)
                n = (n + 10) % 20;
            float YH_sum = (Smoothness_Data_Fi1115[n] + Smoothness_Data_Fi1116[n] + Smoothness_Data_Fi1117[n] + Smoothness_Data_Fi1118[n] + Smoothness_Data_Fitls[n] + Smoothness_Data_Fishccs[n] + Smoothness_Data_Fi201[n]);

            this.textBox15.Text = string.Format("{0:f2}", FI201 + (YH_MI_set / 100 - YH_sum / Data_Wt_fact[n]) * Data_Wt_fact[n]);
            float fi201set = FI201 + (YH_MI_set / 100 - YH_sum / Data_Wt_fact[n]) * Data_Wt_fact[n];
            //WriteTagAI(FI_201_SET, fi201set);
            WriteTagAI(dh_002,fi201set);

            this.textBox1.Text = string.Format("{0:f2}t/h", Wt_fact);
            this.textBox2.Text = string.Format("{0:f2}t/h", sum);
            this.textBox3.Text = string.Format("{0:f2}%", sum / Wt_use * 100);
            this.XHJS.Text = string.Format("{0:f2}t/h", XH_sum);
            this.XHJSZB_textbox.Text = string.Format("{0:f2}%", XH_sum / Wt_use * 100);
            this.textBox10.Text = string.Format("{0:f2}t/h", YH_sum);
            this.textBox11.Text = string.Format("{0:f2}%", YH_sum / Wt_use * 100);
            this.textBox19.Text = string.Format("{0:f2}%", MI_initial);


            float mse17 = MSE(Data_Fi1117, Fi1117);
            this.textBox4.Text = string.Format("{0:f6} / " + gd_mse_Fi1117.ToString(), mse17);
            float mse18 = MSE(Data_Fi1118, Fi1118);
            this.textBox5.Text = string.Format("{0:f6} / " + gd_mse_Fi1118.ToString(), mse18);
            float mse19 = MSE(Data_Fitls, Fitls);
            this.textBox6.Text = string.Format("{0:f6} / " + gd_mse_TL.ToString(), mse19);
            float mse20 = MSE(Data_Fishccs, Fishccs);
            this.textBox7.Text = string.Format("{0:f6} / " + gd_mse_CC.ToString(), mse20);

            n = ((int)Smoothness_Data_Wi117[21] + 19) % 20;
            this.CaO17_textBox.Text = string.Format("{0:f2}", Smoothness_Data_Wi117[n]);

            n = ((int)Smoothness_Data_Wi118[21] + 19) % 20;
            this.CaO18_textBox.Text = string.Format("{0:f2}", Smoothness_Data_Wi118[n]);

            double combine_water = (Smoothness_Data_Wi117[n] + Smoothness_Data_Wi118[n]) * 0.80 / 56 * 16;
            this.textBox17.Text = combine_water.ToString();
            this.textBox18.Text = string.Format("{0:f2}%", combine_water / Wt_fact * 100);

            this.textBox12.Text = string.Format("{0:f2}%", YH_MI_set);
            this.textBox13.Text = string.Format("{0:f2}%", YH_MI_set + MI_initial - combine_water / Wt_fact * 100);
            this.textBox8.Text = string.Format("{0:f2}%", ERH_MI_set);
            this.textBox9.Text = string.Format("{0:f2}%", ERH_MI_set + MI_initial - combine_water / Wt_fact * 100);

            this.label15.Text = string.Format("{0:f2} < ", FI201_down) + string.Format("FI201:{0:f2}", FI201) + string.Format(" < {0:f2}", FI201_up);

            

            

            string temp = "";
            for(int i = 0; i <20; i++)
            {
                temp += string.Format("{0:f2}" + " ", Smoothness_Data_Fi1118[i]);
            }
            this.datebox.Text = temp;
            //更新进度条 + 语音播报提醒
            Remind(mse17, progressBar1, fi1117.tag_name, gd_mse_Fi1117);
            Remind(mse18, progressBar2, fi1118.tag_name, gd_mse_Fi1118);
            Remind(mse19, progressBar3, fitls.tag_name, gd_mse_TL);
            Remind(mse20, progressBar4, fishccs.tag_name, gd_mse_CC);
            try
            {
                if (isPlaying)
                {
                    //string message = dataGridView1.Rows[Play_n].Cells[0].Value.ToString();
                    string message = "加水波动过大警告";
                    await PlayVedio(message);
                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            try
            {
                if (FI201 > FI201_up || FI201 < FI201_down)
                {
                    string message = "一混加水异常";
                    this.label15.ForeColor = Color.Red;
                    time = System.DateTime.Now.ToString();
                    dataGridView1.Rows.Add("FI201", time, FI201);
                    await PlayVedio(message);

                }
                else
                {
                    this.label15.ForeColor = Color.Black;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        private void progressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if(textBox14.Text != "")
            {
                try
                {
                    double value = double.Parse(textBox14.Text);
                    switch (comboBox1.SelectedItem.ToString())
                    {
                        case "17均方差":
                            gd_mse_Fi1117 = value;
                            break;
                        case "18均方差":
                            gd_mse_Fi1118 = value;
                            break;
                        case "除尘水方差":
                            gd_mse_CC = value;
                            break;
                        case "脱硫水方差":
                            gd_mse_TL = value;
                            break;

                    }

                }
                catch (FormatException)
                {

                }


            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox16.Text != "")
            {
                try
                {
                    float value = float.Parse(textBox16.Text);
                    switch (comboBox2.SelectedItem.ToString())
                    {
                        case "一混加水率":
                            YH_MI_set = value;
                            break;
                        case "二混加水率":
                            ERH_MI_set = value;
                            break;
                        case "数据平滑窗体大小":
                            databox = (int)value;
                            break;
                        case "原始水分率":
                            MI_initial = value;
                            break;
                        case "FI201上限":
                            FI201_up = value;
                            break;
                        case "FI201下限":
                            FI201_down = value;
                            break;


                    }

                }
                catch (FormatException)
                {

                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }
    }
}
