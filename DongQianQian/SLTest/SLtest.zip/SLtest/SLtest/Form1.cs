﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CS_Object;
using System.Speech.Synthesis;
using System.Data.SqlClient;
using Excel = Microsoft.Office.Interop.Excel;

namespace SLtest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DL_HL.tag_name = "DL_341";
            SD_HL.tag_name = "SI_341";
            DL_SJJ.tag_name = "DL_SJJ";
            SD_SJJ.tag_name = "SI_301";
        }

        public class Name_IP
        {//用于记录变量名+变量地址
            public string tag_name = "Non";
            public int Ip = 0;
        };

        Name_IP DL_HL = new Name_IP();
        Name_IP SD_HL = new Name_IP();
        Name_IP DL_SJJ = new Name_IP();
        Name_IP SD_SJJ = new Name_IP();

        float[] DL_SJJ_DATA = new float[22];
        float HLDL = 0;
        float HL_set = 31;
        float SDHL;
        float SDSJJ;
        float SJJDL;
        float SJJ_set=54;
       

        String time;

        // 数据库连接字符串
        string connectionString = "Data Source=10.160.8.201;Initial Catalog=CIEexpert_DB1;User ID=sa;Password=cieexpert666";
        // string insertQuery = "INSERT INTO ErrorLog (Time, Column2) VALUES(@Value1,@Value2)";
        string createTableQuery = "CREATE TABLE T_Error_Log (DataName VARCHAR(255), Time VARCHAR(255), Value VARCHAR(50))";

        //创建连接对象的变量  
       public SqlConnection conn;

       /**private void CreateTableBtn_Click(object sender, System.EventArgs e)
       {
           // 打开连接         
           if (conn.State == ConnectionState.Open)
               conn.Close();
           conn.ConnectionString = connectionString;
           conn.Open();
           string sql = "CREATE TABLE ErrorLog Time VARCHAR(255), Value VARCHAR(50)";
           using SqlComand cmd = new SqlCommand(createTableQuery, conn);

           cmd.ExecuteNonQuery();

       }**/

       // 执行对数据表中数据的增加、删除、修改操作  
       public int ExcuteQuery(string sql)  
       {
           conn = new SqlConnection(connectionString);  
           int a = -1;  
           try  
           {  
               conn.Open();  //打开数据库  
               SqlCommand cmd = new SqlCommand(sql, conn);  
               a = cmd.ExecuteNonQuery();  
           }  
           catch  
           {  
  
           }  
           finally  
           {  
               if (conn.State == ConnectionState.Open)  
               {  
                   conn.Close();    //关闭数据库  
               }  
           }  
           return a;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                CS_Object.initServerObject.initRemotServer("10.160.8.202", "TagChannel", "8088");

                // ExcuteQuery(createTableQuery);
                // Console.WriteLine("数据库创建成功");

                //string insertSJJDL = "INSERT INTO T_Error_Log (DataName, Time, Value) VALUES('name_1','time_1','value_1')";
                //ExcuteQuery(insertSJJDL);
            }
            catch { }
        }

        private bool ReadTagAI(Name_IP Tag, ref float Value)
        {
            bool sta = false;
            int reas = 0;
            bool Fx = false;

            try
            {
                if (!CS_Object.initServerObject.Tagserverobject.APIWGetValue(Tag.tag_name, ref Value, ref sta, ref Tag.Ip, ref reas))//本地读
                {
                    Tag.Ip = 0;
                    //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "读不成功！", EventLogEntryType.Error);
                }
                else
                {
                    if (sta) Fx = true;
                }
            }
            catch
            {
                Tag.Ip = 0;
                //EventLog.WriteEntry("SICES_配料优化模型", Tag.Name + "访问不成功！", EventLogEntryType.Error);
            };

            return Fx;
        }
  
        private void timer1_Tick(object sender, EventArgs e)
        {
            //读取数据
            //环冷电流
            ReadTagAI(DL_HL, ref HLDL);
            this.label1.Text = HLDL.ToString();
            this.label3.Text = Convert.ToString(HL_set);

            //烧结电流
            ReadTagAI(DL_SJJ, ref SJJDL);
            this.label12.Text = SJJDL.ToString();
            this.label10.Text = Convert.ToString(SJJ_set);

            //环冷速度
            ReadTagAI(SD_HL, ref SDHL);
            this.label14.Text = SDHL.ToString();
            //this.label3.Text = Convert.ToString(HL_set);

            //烧结速度
            ReadTagAI(SD_SJJ, ref SDSJJ);
            this.label15.Text = SDSJJ.ToString();
            //this.label3.Text = Convert.ToString(HL_set);

            //-----------环冷机电流异常播报-----------------------------------------------------------------
            // 若HLDL电流高于设定值29，则发出异常警告
            if (HLDL > HL_set)
            {
                using (SpeechSynthesizer synthesizer = new SpeechSynthesizer())
                {
                    synthesizer.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Adult);
                    synthesizer.Volume = 100;
                    synthesizer.Rate = 0; // 范围从-10到10
                    String tempHLDL = HLDL.ToString("F2");

                    time = System.DateTime.Now.ToString();

                    // 播放文本
                    synthesizer.Speak("环冷电流" + tempHLDL + "过高！");


                    // 弹窗提示
                    //MessageBox.Show("环冷电流过高！--" + time, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.Rows.Add(time, HLDL);

                    // 将发生异常的时间点及值保存到数据库
                    string insertHLDL = string.Format("INSERT INTO T_Error_Log (DataName, Time, Value) VALUES ('{0}', '{1}', '{2}')", "环冷机电流电流", time, tempHLDL);
                    ExcuteQuery(insertHLDL);
                }
            }
            //-----------烧结机电流异常播报----------------------------------------------------------------
           if (SJJDL > SJJ_set)
           {
               using (SpeechSynthesizer synthesizer = new SpeechSynthesizer())
               {
                   synthesizer.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Adult);
                   synthesizer.Volume = 100;
                   synthesizer.Rate = 0; // 范围从-10到10
                   String tempSJJDL = SJJDL.ToString("F2");

                   time = System.DateTime.Now.ToString();

                   // 播放文本
                   synthesizer.Speak("烧结电流" + tempSJJDL + "过高！");

                   // 显示在列表
                   //MessageBox.Show("环冷电流过高！--" + time, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   dataGridView2.Rows.Add(time, SJJDL);
                   // 将发生异常的时间点及值保存到数据库
                   string insertSJJDL = string.Format("INSERT INTO T_Error_Log (DataName, Time, Value) VALUES ('{0}', '{1}', '{2}')", "烧结机电流", time, tempSJJDL);
                   ExcuteQuery(insertSJJDL);

                   //Form3 Form3 = new Form3();
                   //Form3.Show();
               }
        } 
        }
        public bool IsNumberic(string oText)
        {
            try
            {
                double var1 = Convert.ToDouble(oText);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool t;
            t = IsNumberic(Text1.Text);
            if (t == false)
            {
                MessageBox.Show("请输入一个数字!");
                Text1.Text = ""; //textbox 重置
            }
            else
            {
                HL_set = float.Parse(Text1.Text);
                this.label3.Text = Convert.ToString(HL_set);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 1)
            {
                MessageBox.Show("当前无数据可导出!");
            }
            else
            {
                DataTable dt = new DataTable();
                // 添加列
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    dt.Columns.Add(column.HeaderText);
                }

                // 添加行
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    DataRow dr = dt.NewRow();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        dr[cell.ColumnIndex] = cell.Value;
                    }
                    dt.Rows.Add(dr);
                }
                Export(dt,".\\环冷机异常电流值");
                dt.Rows.Clear();
                dataGridView1.DataSource = dt;
            }
        }
        public static void Export(DataTable dt, string filePath)
        {
            // 创建一个Excel应用程序对象
            Excel.Application excelApp = new Excel.Application();

            // 创建一个新的工作簿
            Excel.Workbook workbook = excelApp.Workbooks.Add(Type.Missing);

            // 创建一个新的工作表并命名为“Sheet1”
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.ActiveSheet;
            worksheet.Name = "Sheet1";

            // 将DataTable的列名写入工作表中
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                worksheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
            }

            // 将DataTable的数据写入工作表中
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dt.Rows[i][j];
                }
            }

            // 保存工作簿
            workbook.SaveAs(filePath, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            // 关闭工作簿和Excel应用程序对象
            workbook.Close();
            excelApp.Quit();

            // 释放Excel对象
            System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool t;
            t = IsNumberic(Text2.Text);
            if (t == false)
            {
                MessageBox.Show("请输入一个数字!");
                Text2.Text = ""; //textbox 重置
            }
            else
            {
                SJJ_set = float.Parse(Text2.Text);
                this.label3.Text = Convert.ToString(HL_set);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView2.Rows.Count == 1)
            {
                MessageBox.Show("当前无数据可导出!");
            }
            else
            {
                DataTable dt = new DataTable();
                // 添加列
                foreach (DataGridViewColumn column in dataGridView2.Columns)
                {
                    dt.Columns.Add(column.HeaderText);
                }

                // 添加行
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    DataRow dr = dt.NewRow();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        dr[cell.ColumnIndex] = cell.Value;
                    }
                    dt.Rows.Add(dr);
                }
                Export(dt, ".\\烧结机异常电流值");
                dt.Rows.Clear();
                dataGridView1.DataSource = dt;
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }



    }
}
